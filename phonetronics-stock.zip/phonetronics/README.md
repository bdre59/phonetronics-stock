# 📱 Phonetronics Stock

Application de gestion de stock en ligne pour votre magasin téléphonie.

## 📁 Fichiers

| Fichier | Rôle |
|---------|------|
| `index.html` | Interface complète (catalogue + admin) |
| `data.js` | Produits par défaut + identifiants admin |
| `app.js` | Logique de l'application |
| `vercel.json` | Configuration Vercel |

---

## 🚀 Déploiement sur Vercel (gratuit, 5 minutes)

### Méthode 1 — Via GitHub (recommandée)

1. Créez un compte gratuit sur [github.com](https://github.com)
2. Créez un nouveau dépôt (bouton **New repository**)
3. Uploadez les 4 fichiers dans le dépôt
4. Créez un compte sur [vercel.com](https://vercel.com) (connexion avec GitHub)
5. Cliquez **Add New Project** → sélectionnez votre dépôt GitHub
6. Cliquez **Deploy** → votre site est en ligne en 1 minute !

Vercel vous donne une URL du type :
```
https://phonetronics-stock.vercel.app
```

### Méthode 2 — Via Vercel CLI

```bash
npm install -g vercel
cd phonetronics
vercel --prod
```

---

## 🔐 Changer le mot de passe admin

Ouvrez `data.js` et modifiez ces deux lignes :

```js
const ADMIN_USER = 'votre_identifiant';
const ADMIN_PASS = 'votre_mot_de_passe_solide';
```

⚠️ **Faites-le avant de déployer** pour sécuriser votre catalogue.

---

## ✏️ Modifier les produits par défaut

Dans `data.js`, modifiez le tableau `DEFAULT_PRODUCTS` :

```js
{ id: 1, name: 'Nom du produit', cat: 'Smartphone', price: 299, stock: 10 },
```

**Catégories disponibles :**
- `Smartphone`
- `Ordinateur`
- `Tablette`
- `Accessoire`
- `Audio`
- `Pièce détachée`

---

## 💡 Fonctionnement

- **Catalogue public** : visible par tout le monde, lecture seule
- **Admin** : protégé par mot de passe, permet d'ajouter/modifier/supprimer des produits
- **QR code** : généré automatiquement avec l'URL de votre site Vercel
- **Données** : sauvegardées dans le navigateur (`localStorage`) — les modifications admin sont persistantes

---

## 📲 Partager le catalogue

Une fois déployé :
1. Allez dans l'onglet **QR & Lien**
2. Collez votre URL Vercel dans le champ "URL personnalisée"
3. Le QR code se met à jour automatiquement
4. Téléchargez le QR code et imprimez-le en magasin !
